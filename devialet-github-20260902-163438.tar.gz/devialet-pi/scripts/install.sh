#!/bin/sh
set -eu

if [ "$(id -u)" -ne 0 ]; then
  echo "Voer dit script uit met sudo: sudo ./scripts/install.sh" >&2
  exit 1
fi

PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
INSTALL_DIR=/opt/devialet
CONFIG_DIR=/etc/devialet
SERVICE_FILE=/etc/systemd/system/devialet-bridge.service

apt-get update
apt-get install -y python3 python3-venv python3-pip

if ! id devialet >/dev/null 2>&1; then
  useradd --system --home-dir "$INSTALL_DIR" --shell /usr/sbin/nologin devialet
fi
usermod -a -G dialout devialet

install -d -o devialet -g devialet "$INSTALL_DIR/src" "$CONFIG_DIR"
cp -R "$PROJECT_DIR/src/." "$INSTALL_DIR/src/"
cp "$PROJECT_DIR/requirements.txt" "$INSTALL_DIR/requirements.txt"
chown -R devialet:devialet "$INSTALL_DIR"

if [ ! -x "$INSTALL_DIR/venv/bin/python" ]; then
  python3 -m venv "$INSTALL_DIR/venv"
fi
"$INSTALL_DIR/venv/bin/pip" install --upgrade pip
"$INSTALL_DIR/venv/bin/pip" install -r "$INSTALL_DIR/requirements.txt"

if [ ! -f "$CONFIG_DIR/devialet.env" ]; then
  install -m 600 "$PROJECT_DIR/.env.example" "$CONFIG_DIR/devialet.env"
  echo "PAS EERST $CONFIG_DIR/devialet.env AAN EN START DAARNA DE SERVICE."
  ENABLE_SERVICE=0
else
  chmod 600 "$CONFIG_DIR/devialet.env"
  ENABLE_SERVICE=1
fi

install -m 644 "$PROJECT_DIR/systemd/devialet-bridge.service" "$SERVICE_FILE"
systemctl daemon-reload

if [ "$ENABLE_SERVICE" -eq 1 ]; then
  systemctl enable --now devialet-bridge.service
  systemctl --no-pager --full status devialet-bridge.service || true
else
  systemctl disable devialet-bridge.service >/dev/null 2>&1 || true
fi
