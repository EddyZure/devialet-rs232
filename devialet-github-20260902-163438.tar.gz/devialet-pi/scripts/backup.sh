#!/bin/sh
set -eu

MODE=${1:-public}
OUTPUT_DIR=${2:-"$(pwd)/backups"}
STAMP=$(date +%Y%m%d-%H%M%S)
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PROJECT_DIR=$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd)
TMP_DIR=$(mktemp -d)
trap 'rm -rf "$TMP_DIR"' EXIT HUP INT TERM
mkdir -p "$OUTPUT_DIR"

case "$MODE" in
  public)
    PACKAGE_DIR="$TMP_DIR/devialet-pi"
    mkdir -p "$PACKAGE_DIR"
    cp -R "$PROJECT_DIR/src" "$PROJECT_DIR/systemd" "$PROJECT_DIR/scripts" "$PROJECT_DIR/docs" "$PACKAGE_DIR/"
    cp "$PROJECT_DIR/README.md" "$PROJECT_DIR/SECURITY.md" "$PROJECT_DIR/VERSION" "$PROJECT_DIR/requirements.txt" "$PROJECT_DIR/.env.example" "$PROJECT_DIR/.gitignore" "$PACKAGE_DIR/"
    ARCHIVE="$OUTPUT_DIR/devialet-github-$STAMP.tar.gz"
    tar -czf "$ARCHIVE" -C "$TMP_DIR" devialet-pi
    ;;
  private)
    if [ "$(id -u)" -ne 0 ]; then
      echo "Private backup vereist sudo om /etc/devialet/devialet.env te lezen." >&2
      exit 1
    fi
    [ -f /etc/devialet/devialet.env ] || { echo "/etc/devialet/devialet.env ontbreekt." >&2; exit 1; }
    mkdir -p "$TMP_DIR/private"
    install -m 600 /etc/devialet/devialet.env "$TMP_DIR/private/devialet.env"
    if [ -d /opt/devialet/src ]; then
      cp -R /opt/devialet/src "$TMP_DIR/private/src"
    else
      cp -R "$PROJECT_DIR/src" "$TMP_DIR/private/src"
    fi
    systemctl cat devialet-bridge.service > "$TMP_DIR/private/devialet-bridge.service.txt" 2>/dev/null || true
    python3 --version > "$TMP_DIR/private/python-version.txt" 2>&1 || true
    ARCHIVE="$OUTPUT_DIR/devialet-private-backup-$STAMP.tar.gz"
    tar -czf "$ARCHIVE" -C "$TMP_DIR" private
    chmod 600 "$ARCHIVE"
    ;;
  *)
    echo "Gebruik: $0 public|private [uitvoermap]" >&2
    exit 1
    ;;
esac

echo "$ARCHIVE"
