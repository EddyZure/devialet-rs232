# Devialet Raspberry Pi Bridge

This bridge connects a Devialet Expert amplifier over RS-232 to MQTT and Home Assistant. It also provides a lightweight local web interface and JSON API.

## Features

- Bidirectional RS-232 communication with the Devialet amplifier
- MQTT status topics and command handling
- Automatic Home Assistant discovery
- Mobile-friendly local web interface
- JSON status and command API with live Server-Sent Events
- Automatic startup and recovery through systemd

## Repository contents

- `src/devialet_bridge.py` — the RS-232, MQTT, Home Assistant, web and API bridge
- `src/devialet_web_assets/` — images used by the web interface
- `systemd/devialet-bridge.service` — systemd service definition
- `.env.example` — configuration template without real credentials
- `scripts/install.sh` — installation and update script for Raspberry Pi OS
- `scripts/backup.sh` — public export and private configuration backup
- `scripts/restore.sh` — private-backup restore script
- `scripts/check-secrets.sh` — basic check for secret files before publishing

Historical development files are intentionally excluded. The repository contains only the latest working version required for deployment.

## Requirements

- Raspberry Pi OS with systemd
- Python 3.7 or newer
- RS-232/USB adapter, normally available as `/dev/ttyUSB0`
- Reachable MQTT broker
- Internet access during initial installation for the Python dependencies

The application uses pure-Python dependencies and does not require a build toolchain.

## Installation

Copy or clone the repository to the Raspberry Pi and run:

```sh
chmod +x scripts/*.sh
sudo ./scripts/install.sh
```

On the first installation, the script creates `/etc/devialet/devialet.env` but does not start the service. Edit the file and replace the example values:

```sh
sudo nano /etc/devialet/devialet.env
```

Then enable and start the bridge:

```sh
sudo systemctl enable --now devialet-bridge.service
```

Verify the service and local API:

```sh
sudo systemctl status devialet-bridge.service
curl http://127.0.0.1:8080/api/status
```

The web interface is available at `http://<raspberry-pi-ip-address>:8080/`.

Running the installer again updates the application, dependencies and service definition while preserving `/etc/devialet/devialet.env`.

## Configuration

| Variable | Purpose | Default/example |
| --- | --- | --- |
| `MQTT_HOST` | MQTT broker address | required |
| `MQTT_PORT` | MQTT broker port | `1883` |
| `MQTT_USERNAME` | MQTT username | required |
| `MQTT_PASSWORD` | MQTT password | required |
| `SERIAL_PORT` | RS-232 device | `/dev/ttyUSB0` |
| `SERIAL_BAUDRATE` | Serial baud rate | `115200` |
| `HTTP_HOST` | Web/API listening address | `0.0.0.0` |
| `HTTP_PORT` | Web/API port | `8080` |

The real configuration file is installed with mode `600` and must never be committed. If the USB adapter does not always receive the same device number, use a stable path from `/dev/serial/by-id/` for `SERIAL_PORT`.

## Backups

Create a GitHub-safe export without credentials:

```sh
./scripts/backup.sh public
```

This creates `backups/devialet-github-<date>.tar.gz`. It contains only repository files and the safe `.env.example` template.

Create a private local backup containing the real configuration:

```sh
sudo ./scripts/backup.sh private /path/to/secure/external/storage
```

The private archive is assigned mode `600`, but it is **not encrypted**. Never publish it or upload it to GitHub. Store it on encrypted media or encrypt it before placing it elsewhere.

The Raspberry Pi 1B migration procedure is documented separately in [PI1B_RESTORE.md](docs/PI1B_RESTORE.md).

## Publishing on GitHub

Before every push, run:

```sh
./scripts/check-secrets.sh
git status
```

Commit the repository contents, never a private backup. Add a license only after deliberately selecting one; without a license, other people may view the source but do not automatically receive permission to reuse it.

## API

- `GET /api/status` — returns the current state
- `GET /api/events` — streams live state changes using Server-Sent Events
- `POST /api/command` — accepts commands as JSON

Example command:

```json
{"name": "VOLUME", "value": "-35.0"}
```

The API does not include user authentication. Do not expose port 8080 directly to the internet. Use it only on a trusted LAN or VPN, or place an authenticated HTTPS reverse proxy in front of the bridge.

## Troubleshooting

```sh
sudo journalctl -u devialet-bridge.service -n 100 --no-pager
ls -l /dev/ttyUSB0 /dev/serial/by-id/ 2>/dev/null
```

Common causes of startup problems are an incorrect serial device path, a disconnected adapter, an unreachable MQTT broker or unchanged example credentials.
