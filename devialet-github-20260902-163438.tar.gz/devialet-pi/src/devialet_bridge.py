#!/usr/bin/env python3

import json
import os
import queue
import re
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import paho.mqtt.client as mqtt
import serial

PORT = os.environ.get("SERIAL_PORT", "/dev/ttyUSB0")
BAUDRATE = int(os.environ.get("SERIAL_BAUDRATE", "115200"))
RECONNECT_DELAY = 5
READY_QUERY_INTERVAL = 2.0
HTTP_HOST = os.environ.get("HTTP_HOST", "0.0.0.0")
HTTP_PORT = int(os.environ.get("HTTP_PORT", "8080"))
WEB_ASSET_DIR = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "devialet_web_assets",
)

MQTT_HOST = os.environ["MQTT_HOST"]
MQTT_PORT = int(os.environ.get("MQTT_PORT", "1883"))
MQTT_USERNAME = os.environ["MQTT_USERNAME"]
MQTT_PASSWORD = os.environ["MQTT_PASSWORD"]

MESSAGE_PATTERN = re.compile(
    r"^\[Devialet>([A-Z0-9_]+)([:=])(.+)\]$"
)

QUERY_NAMES = (
    "POWER",
    "START",
    "STOP",
    "SOURCE",
    "VOLUME",
    "MUTE",
    "BALANCE",
    "TONE_CONTROL",
    "BASS",
    "TREBLE",
    "PREOUT",
    "SUBWOOFER",
    "PHASE",
    "SUBSONIC_FILTER",
    "MATCHING_LEVEL",
)

WEB_COMMAND_NAMES = {
    "POWER",
    "MUTE",
    "PREOUT",
    "SUBWOOFER",
    "SOURCE",
    "VOLUME",
    "BASS",
    "TREBLE",
    "BALANCE",
    "MATCHING_LEVEL",
}

state = {
    "POWER": None,
    "START": None,
    "STOP": None,
    "SERIAL": "disconnected",
}
state_lock = threading.RLock()
state_condition = threading.Condition(state_lock)
state_updated_at = None
state_revision = 0

command_queue = queue.Queue()
previous_ready = None
full_status_refresh_pending = False
web_status_query_due = None
web_status_query_names = set()


def is_ready():
    with state_lock:
        return (
            state.get("POWER") == "1"
            and state.get("START") == "0"
            and state.get("STOP") == "0"
        )


def store_status(name, value):
    global state_revision, state_updated_at

    with state_condition:
        state[name] = value
        state_updated_at = time.time()
        state_revision += 1
        state_condition.notify_all()


def status_snapshot():
    with state_lock:
        values = {
            name.lower(): value
            for name, value in state.items()
        }
        updated_at = state_updated_at

    values["ready"] = (
        values.get("power") == "1"
        and values.get("start") == "0"
        and values.get("stop") == "0"
    )

    return {
        "status": values,
        "updated_at": updated_at,
    }


def wait_for_status(last_revision, timeout=15):
    with state_condition:
        if state_revision == last_revision:
            state_condition.wait(timeout)

        revision = state_revision

    return revision, status_snapshot()


def schedule_web_status_query(name):
    global web_status_query_due

    with state_lock:
        web_status_query_names.add(name)
        web_status_query_due = time.monotonic() + 0.6


def publish(topic, payload, retain=True):
    mqtt_client.publish(
        f"devialet/{topic}",
        str(payload),
        qos=1,
        retain=retain,
    )


def update_ready():
    global full_status_refresh_pending, previous_ready

    ready = is_ready()

    if ready != previous_ready:
        print(f"Devialet gereed: {ready}", flush=True)
        publish("status/ready", str(ready).lower())

        if ready and previous_ready is False:
            full_status_refresh_pending = True

        previous_ready = ready


def process_message(message):
    match = MESSAGE_PATTERN.match(message)

    if not match:
        print(f"Niet herkende melding: {message}", flush=True)
        return

    name, separator, value = match.groups()

    if separator == "=" and value == "ACK":
        print(f"Commando bevestigd: {name}", flush=True)
        publish("status/last_ack", name, retain=False)
        return

    store_status(name, value)
    print(f"Status bijgewerkt: {name}={value}", flush=True)
    publish(f"status/{name.lower()}", value)
    update_ready()


STATUS_PAGE = """<!doctype html>
<html lang="nl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
  <meta name="theme-color" content="#111111">
  <title>Devialet Expert Pro 440</title>
  <style>
    :root {
      color-scheme: dark;
      --amber: #ffb800;
      --ink: #171717;
      --panel: #777776;
      --control: #242424;
      --muted: #a8a8a8;
      --line: rgba(255,184,0,.55);
    }
    * { box-sizing: border-box; }
    button, select { font: inherit; color: inherit; }
    button { border: 0; }
    html { background: #0e0e0e; }
    body {
      margin: 0;
      min-height: 100vh;
      background: #0e0e0e;
      color: #f4f4f4;
      font: 600 14px/1.2 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      -webkit-font-smoothing: antialiased;
    }
    .shell {
      width: min(100%, 520px);
      min-height: 100vh;
      margin: 0 auto;
      padding: max(12px, env(safe-area-inset-top)) 12px max(18px, env(safe-area-inset-bottom));
      background: var(--panel);
    }
    .hero {
      display: block;
      width: 100%;
      aspect-ratio: 10 / 3;
      object-fit: cover;
      border-radius: 23px;
      background: #080a0a;
      box-shadow: inset 0 0 0 1px rgba(255,255,255,.08);
    }
    .quick {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 8px;
      margin: 9px 0;
    }
    .pill, .source, .meter, .tone {
      background: var(--control);
      box-shadow: inset 0 0 0 1px rgba(255,255,255,.05);
    }
    .pill {
      min-width: 0;
      height: 44px;
      border-radius: 999px;
      display: flex;
      align-items: center;
      gap: 7px;
      padding: 0 12px;
      white-space: nowrap;
      cursor: pointer;
      text-align: left;
      color: #f4f4f4;
      touch-action: manipulation;
    }
    .icon {
      width: 22px;
      height: 22px;
      flex: 0 0 22px;
      display: grid;
      place-items: center;
      color: #d8d8d8;
    }
    .icon svg {
      width: 100%;
      height: 100%;
      display: block;
      fill: currentColor;
    }
    .tone-status-icon,
    .tone-dependent .icon {
      transition: color .2s ease;
    }
    .tone-flat .tone-status-icon,
    .tone-flat .tone-dependent .icon {
      color: #777;
    }
    .shell:not(.tone-flat) .tone-status-icon {
      color: var(--amber);
    }
    .pill.active .icon, .status-online { color: var(--amber); }
    .icon .mute-on-icon { display: none; }
    .pill.active .icon .mute-off-icon { display: none; }
    .pill.active .icon .mute-on-icon { display: block; }
    .source {
      height: 56px;
      border-radius: 12px;
      display: grid;
      grid-template-columns: 36px 1fr 1.35fr;
      align-items: center;
      padding: 0 10px 0 12px;
      margin-bottom: 8px;
    }
    .source-value {
      width: 100%;
      border: 0;
      padding: 12px 16px;
      border-radius: 13px;
      background: #2e2e2e;
      font-weight: 500;
      text-align: left;
      outline: none;
      cursor: pointer;
    }
    .source > .icon {
      width: 32px;
      height: 32px;
      padding: 5px;
      border-radius: 50%;
      background: #202020;
    }
    .metric {
      display: grid;
      grid-template-columns: minmax(0, 1fr) 68px 42px 42px;
      gap: 8px;
      align-items: center;
      margin: 8px 0;
    }
    .meter {
      position: relative;
      height: 50px;
      overflow: hidden;
      border-radius: 999px;
      cursor: pointer;
      touch-action: none;
      user-select: none;
    }
    .meter.dragging { outline: 2px solid rgba(255,184,0,.72); }
    .meter[aria-disabled="true"] { cursor: not-allowed; opacity: .43; }
    .meter-fill {
      position: absolute;
      inset: 0 auto 0 0;
      width: var(--fill, 0%);
      min-width: 0;
      background: var(--amber);
      transition: width .22s ease;
    }
    .meter-label {
      position: relative;
      z-index: 1;
      height: 100%;
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 0 13px 0 4px;
      text-shadow: 0 1px 2px #000;
    }
    .meter-label > .icon {
      width: 42px;
      height: 42px;
      flex-basis: 42px;
      padding: 9px;
      border-radius: 50%;
      background: #202020;
    }
    .volume-row .meter-label > .icon {
      box-shadow: 0 0 0 5px var(--amber);
    }
    .round-value, .round {
      height: 42px;
      border-radius: 999px;
      background: var(--control);
      display: grid;
      place-items: center;
    }
    .round-value { padding: 0 9px; white-space: nowrap; font-size: 12px; }
    .round { font-size: 25px; color: #ddd; }
    button.round {
      padding: 0;
      cursor: pointer;
      touch-action: manipulation;
    }
    button.round:active,
    button.pill:active,
    button.tone:active {
      transform: scale(.96);
    }
    button:disabled,
    select:disabled {
      cursor: not-allowed;
      opacity: .43;
    }
    .section {
      margin: 16px 0 7px;
      padding-top: 8px;
      border-top: 1px solid var(--line);
      border-radius: 11px 11px 0 0;
    }
    .tone {
      width: max-content;
      max-width: 100%;
      min-height: 40px;
      margin: 0 auto;
      border-radius: 999px;
      display: flex;
      align-items: center;
      gap: 9px;
      padding: 0 19px;
      font-size: 11px;
    }
    button.tone { cursor: pointer; color: #f4f4f4; }
    .tone > .icon { width: 18px; height: 18px; flex-basis: 18px; }
    .sam-logo {
      width: 48px;
      height: 30px;
      object-fit: contain;
      background: #050505;
      filter: invert(1) grayscale(1) opacity(.72);
      transition: filter .2s ease;
    }
    .sam-enabled .sam-logo {
      filter: invert(1) sepia(1) saturate(12) hue-rotate(350deg) brightness(.95);
    }
    .foot {
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 7px;
      min-height: 24px;
      color: rgba(20,20,20,.72);
      font-size: 10px;
      font-weight: 500;
    }
    .dot { width: 5px; height: 5px; border-radius: 50%; background: currentColor; }
    .connection-lost { color: #ffd36b; }
    @media (max-width: 410px) {
      .shell { padding-left: 8px; padding-right: 8px; }
      .quick { gap: 5px; }
      .pill { padding: 0 8px; gap: 4px; font-size: 12px; }
      .metric { grid-template-columns: minmax(0, 1fr) 62px 38px 38px; gap: 5px; }
      .round { font-size: 21px; }
    }
    @media (min-width: 760px) {
      body { display: grid; place-items: start center; padding: 24px; }
      .shell { min-height: auto; border-radius: 18px; box-shadow: 0 20px 70px #000; }
    }
  </style>
</head>
<body>
  <svg width="0" height="0" aria-hidden="true" style="position:absolute">
    <symbol id="mdi-power" viewBox="0 0 24 24"><path d="M16.56,5.44L15.11,6.89C16.84,7.94 18,9.83 18,12A6,6 0 0,1 12,18A6,6 0 0,1 6,12C6,9.83 7.16,7.94 8.88,6.88L7.44,5.44C5.36,6.88 4,9.28 4,12A8,8 0 0,0 12,20A8,8 0 0,0 20,12C20,9.28 18.64,6.88 16.56,5.44M13,3H11V13H13"/></symbol>
    <symbol id="mdi-volume-mute" viewBox="0 0 24 24"><path d="M3,9H7L12,4V20L7,15H3V9M16.59,12L14,9.41L15.41,8L18,10.59L20.59,8L22,9.41L19.41,12L22,14.59L20.59,16L18,13.41L15.41,16L14,14.59L16.59,12Z"/></symbol>
    <symbol id="mdi-volume-medium" viewBox="0 0 24 24"><path d="M5,9V15H9L14,20V4L9,9M18.5,12C18.5,10.23 17.5,8.71 16,7.97V16C17.5,15.29 18.5,13.76 18.5,12Z"/></symbol>
    <symbol id="mdi-audio-input-rca" viewBox="0 0 24 24"><path d="M11 6V12H5V6H7V2C7 1.45 7.45 1 8 1S9 1.45 9 2V6H11M5 14V16C5 17.3 5.84 18.4 7 18.82V23H9V18.82C10.16 18.4 11 17.3 11 16V14H5M17 6V2C17 1.45 16.55 1 16 1S15 1.45 15 2V6H13V12H19V6H17M13 14V16C13 17.3 13.84 18.4 15 18.82V23H17V18.82C18.16 18.4 19 17.3 19 16V14H13Z"/></symbol>
    <symbol id="mdi-speaker" viewBox="0 0 24 24"><path d="M12,12A3,3 0 0,0 9,15A3,3 0 0,0 12,18A3,3 0 0,0 15,15A3,3 0 0,0 12,12M12,20A5,5 0 0,1 7,15A5,5 0 0,1 12,10A5,5 0 0,1 17,15A5,5 0 0,1 12,20M12,4A2,2 0 0,1 14,6A2,2 0 0,1 12,8C10.89,8 10,7.1 10,6C10,4.89 10.89,4 12,4M17,2H7C5.89,2 5,2.89 5,4V20A2,2 0 0,0 7,22H17A2,2 0 0,0 19,20V4C19,2.89 18.1,2 17,2Z"/></symbol>
    <symbol id="mdi-power-plug" viewBox="0 0 24 24"><path d="M16,7V3H14V7H10V3H8V7H8C7,7 6,8 6,9V14.5L9.5,18V21H14.5V18L18,14.5V9C18,8 17,7 16,7Z"/></symbol>
    <symbol id="mdi-volume-high" viewBox="0 0 24 24"><path d="M14,3.23V5.29C16.89,6.15 19,8.83 19,12C19,15.17 16.89,17.84 14,18.7V20.77C18,19.86 21,16.28 21,12C21,7.72 18,4.14 14,3.23M16.5,12C16.5,10.23 15.5,8.71 14,7.97V16C15.5,15.29 16.5,13.76 16.5,12M3,9V15H7L12,20V4L7,9H3Z"/></symbol>
    <symbol id="mdi-tune-variant" viewBox="0 0 24 24"><path d="M8 13C6.14 13 4.59 14.28 4.14 16H2V18H4.14C4.59 19.72 6.14 21 8 21S11.41 19.72 11.86 18H22V16H11.86C11.41 14.28 9.86 13 8 13M8 19C6.9 19 6 18.1 6 17C6 15.9 6.9 15 8 15S10 15.9 10 17C10 18.1 9.1 19 8 19M19.86 6C19.41 4.28 17.86 3 16 3S12.59 4.28 12.14 6H2V8H12.14C12.59 9.72 14.14 11 16 11S19.41 9.72 19.86 8H22V6H19.86M16 9C14.9 9 14 8.1 14 7C14 5.9 14.9 5 16 5S18 5.9 18 7C18 8.1 17.1 9 16 9Z"/></symbol>
    <symbol id="mdi-music-clef-treble" viewBox="0 0 24 24"><path d="M13 11V7.5L15.2 5.29C16 4.5 16.15 3.24 15.59 2.26C15.14 1.47 14.32 1 13.45 1C13.24 1 13 1.03 12.81 1.09C11.73 1.38 11 2.38 11 3.5V6.74L7.86 9.91C6.2 11.6 5.7 14.13 6.61 16.34C7.38 18.24 9.06 19.55 11 19.89V20.5C11 20.76 10.77 21 10.5 21H9V23H10.5C11.85 23 13 21.89 13 20.5V20C15.03 20 17.16 18.08 17.16 15.25C17.16 12.95 15.24 11 13 11M13 3.5C13 3.27 13.11 3.09 13.32 3.03C13.54 2.97 13.77 3.06 13.88 3.26C14 3.46 13.96 3.71 13.8 3.87L13 4.73V3.5M11 11.5C10.03 12.14 9.3 13.24 9.04 14.26L11 14.78V17.83C9.87 17.53 8.9 16.71 8.43 15.57C7.84 14.11 8.16 12.45 9.26 11.33L11 9.5V11.5M13 18V12.94C14.17 12.94 15.18 14.04 15.18 15.25C15.18 17 13.91 18 13 18Z"/></symbol>
    <symbol id="mdi-arrow-left-right" viewBox="0 0 24 24"><path d="M6.45,17.45L1,12L6.45,6.55L7.86,7.96L4.83,11H19.17L16.14,7.96L17.55,6.55L23,12L17.55,17.45L16.14,16.04L19.17,13H4.83L7.86,16.04L6.45,17.45Z"/></symbol>
    <symbol id="mdi-waveform" viewBox="0 0 24 24"><path d="M22 12L20 13L19 14L18 13L17 16L16 13L15 21L14 13L13 15L12 13L11 17L10 13L9 22L8 13L7 19L6 13L5 14L4 13L2 12L4 11L5 10L6 11L7 5L8 11L9 2L10 11L11 7L12 11L13 9L14 11L15 3L16 11L17 8L18 11L19 10L20 11L22 12Z"/></symbol>
  </svg>
  <main class="shell">
    <img id="hero" class="hero" src="/assets/header-power-off.jpg" alt="Devialet Expert Pro 440">

    <section class="quick" aria-label="Hoofdstatus">
      <button type="button" class="pill" data-binary="power" data-toggle="POWER" disabled><span class="icon"><svg><use href="#mdi-power"/></svg></span><span>Power</span></button>
      <button type="button" class="pill" data-binary="mute" data-toggle="MUTE" data-requires-ready disabled><span class="icon"><svg class="mute-off-icon"><use href="#mdi-volume-medium"/></svg><svg class="mute-on-icon"><use href="#mdi-volume-mute"/></svg></span><span>Mute</span></button>
      <button type="button" class="pill" data-binary="preout" data-toggle="PREOUT" data-requires-ready><span class="icon"><svg><use href="#mdi-audio-input-rca"/></svg></span><span>Pre-out</span></button>
      <button type="button" class="pill" data-binary="subwoofer" data-toggle="SUBWOOFER" data-requires-ready><span class="icon"><svg><use href="#mdi-speaker"/></svg></span><span>Sub</span></button>
    </section>

    <section class="source" aria-label="Bron">
      <span class="icon status-online"><svg><use href="#mdi-audio-input-rca"/></svg></span>
      <span>Source</span>
      <select id="source" class="source-value" data-requires-ready aria-label="Source" disabled>
        <option>AES/EBU</option><option>Optical 1</option><option>USB</option>
        <option>Denon AVR</option><option>Phono</option><option>UPnP</option>
        <option>Roon Ready</option><option>AirPlay</option><option>Spotify</option><option>Air</option>
      </select>
    </section>

    <section class="metric volume-row">
      <div class="meter" data-slider="VOLUME" data-output="volume" data-fill="volume-fill" data-step="0.5" data-min="-80" data-max="10" aria-disabled="true"><div id="volume-fill" class="meter-fill"></div><div class="meter-label"><span class="icon"><svg><use href="#mdi-volume-high"/></svg></span>Volume</div></div>
      <output id="volume" class="round-value">—</output><button type="button" class="round" data-adjust="VOLUME" data-step="-0.5" data-min="-80" data-max="10" data-requires-ready aria-label="Volume lager">−</button><button type="button" class="round" data-adjust="VOLUME" data-step="0.5" data-min="-80" data-max="10" data-requires-ready aria-label="Volume hoger">+</button>
    </section>

    <section class="section">
      <button type="button" id="tone-reset" class="tone" data-requires-ready><span class="icon tone-status-icon"><svg><use href="#mdi-tune-variant"/></svg></span><span id="tone-control">Tone Control · —</span></button>
    </section>

    <section class="metric tone-dependent">
      <div class="meter" data-slider="BASS" data-output="bass" data-fill="bass-fill" data-step="0.5" data-min="-18" data-max="18"><div id="bass-fill" class="meter-fill"></div><div class="meter-label"><span class="icon"><svg><use href="#mdi-tune-variant"/></svg></span>Bass</div></div>
      <output id="bass" class="round-value">—</output><button type="button" class="round" data-adjust="BASS" data-step="-0.5" data-min="-18" data-max="18" data-requires-ready aria-label="Bass lager">−</button><button type="button" class="round" data-adjust="BASS" data-step="0.5" data-min="-18" data-max="18" data-requires-ready aria-label="Bass hoger">+</button>
    </section>
    <section class="metric tone-dependent">
      <div class="meter" data-slider="TREBLE" data-output="treble" data-fill="treble-fill" data-step="0.5" data-min="-18" data-max="18"><div id="treble-fill" class="meter-fill"></div><div class="meter-label"><span class="icon"><svg><use href="#mdi-music-clef-treble"/></svg></span>Treble</div></div>
      <output id="treble" class="round-value">—</output><button type="button" class="round" data-adjust="TREBLE" data-step="-0.5" data-min="-18" data-max="18" data-requires-ready aria-label="Treble lager">−</button><button type="button" class="round" data-adjust="TREBLE" data-step="0.5" data-min="-18" data-max="18" data-requires-ready aria-label="Treble hoger">+</button>
    </section>
    <section class="metric tone-dependent">
      <div class="meter" data-slider="BALANCE" data-output="balance" data-fill="balance-fill" data-step="1" data-min="-100" data-max="100"><div id="balance-fill" class="meter-fill"></div><div class="meter-label"><span class="icon"><svg><use href="#mdi-arrow-left-right"/></svg></span>Balance</div></div>
      <output id="balance" class="round-value">—</output><button type="button" class="round" data-adjust="BALANCE" data-step="-1" data-min="-100" data-max="100" data-requires-ready aria-label="Balance links">L</button><button type="button" class="round" data-adjust="BALANCE" data-step="1" data-min="-100" data-max="100" data-requires-ready aria-label="Balance rechts">R</button>
    </section>

    <section class="section">
      <button type="button" id="sam-toggle" class="tone" data-requires-ready><img class="sam-logo" src="/assets/sam-processing-logo.png" alt="SAM"><span>Speaker Active Matching – <span id="sam-active">—</span></span></button>
    </section>
    <section class="metric">
      <div class="meter" data-slider="MATCHING_LEVEL" data-state-key="matching_level" data-output="sam" data-fill="sam-fill" data-step="1" data-min="0" data-max="100"><div id="sam-fill" class="meter-fill"></div><div class="meter-label"><span class="icon"><svg><use href="#mdi-waveform"/></svg></span>SAM%</div></div>
      <output id="sam" class="round-value">—</output><button type="button" class="round" data-adjust="MATCHING_LEVEL" data-state-key="matching_level" data-step="-1" data-min="0" data-max="100" data-requires-ready aria-label="SAM lager">−</button><button type="button" class="round" data-adjust="MATCHING_LEVEL" data-state-key="matching_level" data-step="1" data-min="0" data-max="100" data-requires-ready aria-label="SAM hoger">+</button>
    </section>

    <footer id="connection" class="foot"><span class="dot"></span><span>verbinden…</span></footer>
  </main>
  <script>
    const byId = (id) => document.getElementById(id);
    const number = (value, fallback = 0) => {
      const parsed = Number.parseFloat(value);
      return Number.isFinite(parsed) ? parsed : fallback;
    };
    const percent = (value, min, max) =>
      Math.max(0, Math.min(100, ((number(value, min) - min) / (max - min)) * 100));
    const db = (value) => value == null ? '—' : `${number(value).toFixed(1).replace('.', ',')} dB`;
    const delay = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds));
    let currentStatus = {};
    const pendingValues = new Map();
    let lastSamLevel = 100;
    let messageTimer;
    document.querySelectorAll('[data-requires-ready]').forEach((control) => control.disabled = true);
    document.querySelectorAll('[data-slider]').forEach((slider) => slider.setAttribute('aria-disabled', 'true'));

    function stateKey(name, element) {
      return element?.dataset.stateKey || name.toLowerCase();
    }

    function connectionMessage(text, isError = false) {
      const connection = byId('connection');
      clearTimeout(messageTimer);
      connection.classList.toggle('connection-lost', isError);
      connection.lastElementChild.textContent = text;
      messageTimer = setTimeout(() => {
        const online = currentStatus.serial === 'connected';
        connection.classList.toggle('connection-lost', !online);
        connection.lastElementChild.textContent = online ? 'RS-232 verbonden · live status' : 'RS-232 niet verbonden';
      }, 2200);
    }

    async function sendCommand(name, value) {
      try {
        const response = await fetch('/api/command', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({name, value: String(value)}),
        });
        const result = await response.json();

        if (!response.ok) throw new Error(result.error || 'Opdracht geweigerd');
        return true;
      } catch (error) {
        connectionMessage(error.message || 'Opdracht mislukt', true);
        return false;
      }
    }

    function render(data) {
      const s = data.status || {};
      currentStatus = s;
      const powered = s.power === '1';
      byId('hero').src = powered ? '/assets/header-power-on.jpg' : '/assets/header-power-off.jpg';
      document.querySelectorAll('[data-binary]').forEach((item) => {
        item.classList.toggle('active', s[item.dataset.binary] === '1');
      });
      if (s.source && byId('source').value !== s.source) byId('source').value = s.source;
      byId('volume').textContent = db(s.volume);
      byId('volume-fill').style.setProperty('--fill', `${percent(s.volume, -80, 10)}%`);
      document.querySelector('.shell').classList.toggle('tone-flat', s.tone_control !== '1');
      byId('tone-control').textContent = `Tone Control · ${s.tone_control === '1' ? 'Active' : 'Flat'}`;
      byId('bass').textContent = db(s.bass);
      byId('bass-fill').style.setProperty('--fill', `${percent(s.bass, -18, 18)}%`);
      byId('treble').textContent = db(s.treble);
      byId('treble-fill').style.setProperty('--fill', `${percent(s.treble, -18, 18)}%`);
      byId('balance').textContent = s.balance == null ? '—' : `${number(s.balance).toFixed(0)}%`;
      byId('balance-fill').style.setProperty('--fill', `${percent(s.balance, -100, 100)}%`);
      byId('sam').textContent = s.matching_level == null ? '—' : `${number(s.matching_level).toFixed(0)}%`;
      byId('sam-fill').style.setProperty('--fill', `${percent(s.matching_level, 0, 100)}%`);
      if (number(s.matching_level) > 0) lastSamLevel = number(s.matching_level);
      document.querySelector('.shell').classList.toggle('sam-enabled', number(s.matching_level) > 0);
      byId('sam-active').textContent = number(s.matching_level) > 0 ? 'Active' : 'Inactive';
      const online = s.serial === 'connected';
      document.querySelector('[data-toggle="POWER"]').disabled = !online;
      document.querySelectorAll('[data-requires-ready]').forEach((control) => {
        control.disabled = !online || s.ready !== true || control.dataset.busy === 'true';
      });
      document.querySelectorAll('[data-slider]').forEach((slider) => {
        slider.setAttribute('aria-disabled', !online || s.ready !== true ? 'true' : 'false');
      });
      byId('connection').classList.toggle('connection-lost', !online);
      byId('connection').lastElementChild.textContent = online ? 'RS-232 verbonden · live status' : 'RS-232 niet verbonden';
    }

    document.querySelectorAll('[data-toggle]').forEach((control) => {
      control.addEventListener('click', async () => {
        const name = control.dataset.toggle;
        const key = stateKey(name, control);
        const pending = pendingValues.get(name);
        const current = pending && pending.expires > Date.now() ? pending.value : currentStatus[key];
        const value = current === '1' ? '0' : '1';
        pendingValues.set(name, {value, expires: Date.now() + 1500});

        if (!await sendCommand(name, value)) pendingValues.delete(name);
      });
    });

    byId('tone-reset').addEventListener('click', async () => {
      const button = byId('tone-reset');
      button.dataset.busy = 'true';
      button.disabled = true;

      try {
        for (const resetName of ['BASS', 'TREBLE', 'BALANCE']) {
          pendingValues.set(resetName, {value: '0', expires: Date.now() + 2500});

          if (!await sendCommand(resetName, '0')) {
            pendingValues.delete(resetName);
            return;
          }

          await delay(260);
        }
      } finally {
        delete button.dataset.busy;
        button.disabled = currentStatus.serial !== 'connected' || currentStatus.ready !== true;
      }
    });

    byId('sam-toggle').addEventListener('click', async () => {
      const current = number(currentStatus.matching_level);
      const value = current > 0 ? '0' : String(Math.max(1, Math.round(lastSamLevel)));
      pendingValues.set('MATCHING_LEVEL', {value, expires: Date.now() + 1500});

      if (!await sendCommand('MATCHING_LEVEL', value)) pendingValues.delete('MATCHING_LEVEL');
    });

    byId('source').addEventListener('change', async (event) => {
      if (!await sendCommand('SOURCE', event.target.value)) {
        event.target.value = currentStatus.source || '';
      }
    });

    function adjust(button) {
      const name = button.dataset.adjust;
      const key = stateKey(name, button);
      const pending = pendingValues.get(name);
      const base = pending && pending.expires > Date.now() ? number(pending.value) : number(currentStatus[key]);
      const step = number(button.dataset.step);
      const minimum = number(button.dataset.min);
      const maximum = number(button.dataset.max);
      const next = Math.max(minimum, Math.min(maximum, base + step));
      const integerValue = name === 'BALANCE' || name === 'MATCHING_LEVEL';
      const value = integerValue ? String(Math.round(next)) : next.toFixed(1);
      pendingValues.set(name, {value, expires: Date.now() + 1500});
      sendCommand(name, value).then((accepted) => {
        if (!accepted) pendingValues.delete(name);
      });
    }

    document.querySelectorAll('[data-adjust]').forEach((button) => {
      let holdTimer;
      let repeatTimer;
      let held = false;

      const stopHold = () => {
        clearTimeout(holdTimer);
        clearInterval(repeatTimer);
      };

      button.addEventListener('pointerdown', () => {
        held = false;
        holdTimer = setTimeout(() => {
          held = true;
          adjust(button);
          repeatTimer = setInterval(() => adjust(button), 180);
        }, 420);
      });
      button.addEventListener('pointerup', stopHold);
      button.addEventListener('pointercancel', stopHold);
      button.addEventListener('pointerleave', stopHold);
      button.addEventListener('click', (event) => {
        if (held) {
          event.preventDefault();
          held = false;
          return;
        }
        adjust(button);
      });
    });

    function sliderValue(slider, event) {
      const rect = slider.getBoundingClientRect();
      const minimum = number(slider.dataset.min);
      const maximum = number(slider.dataset.max);
      const step = number(slider.dataset.step, 1);
      const ratio = Math.max(0, Math.min(1, (event.clientX - rect.left) / rect.width));
      const raw = minimum + ratio * (maximum - minimum);
      const snapped = minimum + Math.round((raw - minimum) / step) * step;
      return Math.max(minimum, Math.min(maximum, snapped));
    }

    function previewSlider(slider, value) {
      const name = slider.dataset.slider;
      const minimum = number(slider.dataset.min);
      const maximum = number(slider.dataset.max);
      byId(slider.dataset.fill).style.setProperty('--fill', `${percent(value, minimum, maximum)}%`);

      if (name === 'VOLUME' || name === 'BASS' || name === 'TREBLE') {
        byId(slider.dataset.output).textContent = db(value);
      } else {
        byId(slider.dataset.output).textContent = `${Math.round(value)}%`;
      }

      if (name === 'MATCHING_LEVEL') {
        document.querySelector('.shell').classList.toggle('sam-enabled', value > 0);
        byId('sam-active').textContent = value > 0 ? 'Active' : 'Inactive';
      }
    }

    function sendSlider(slider, value) {
      const name = slider.dataset.slider;
      const integerValue = name === 'BALANCE' || name === 'MATCHING_LEVEL';
      const commandValue = integerValue ? String(Math.round(value)) : value.toFixed(1);
      pendingValues.set(name, {value: commandValue, expires: Date.now() + 1500});
      sendCommand(name, commandValue).then((accepted) => {
        if (!accepted) pendingValues.delete(name);
      });
    }

    document.querySelectorAll('[data-slider]').forEach((slider) => {
      let dragging = false;
      let lastSent = 0;

      const updateSlider = (event, forceSend = false) => {
        const value = sliderValue(slider, event);
        previewSlider(slider, value);
        const now = Date.now();

        if (forceSend || now - lastSent >= 140) {
          lastSent = now;
          sendSlider(slider, value);
        }
      };

      slider.addEventListener('pointerdown', (event) => {
        if (slider.getAttribute('aria-disabled') === 'true') return;
        event.preventDefault();
        dragging = true;
        slider.classList.add('dragging');
        slider.setPointerCapture(event.pointerId);
        updateSlider(event, true);
      });
      slider.addEventListener('pointermove', (event) => {
        if (dragging) updateSlider(event);
      });
      slider.addEventListener('pointerup', (event) => {
        if (!dragging) return;
        updateSlider(event, true);
        dragging = false;
        slider.classList.remove('dragging');
        slider.releasePointerCapture(event.pointerId);
      });
      slider.addEventListener('pointercancel', () => {
        dragging = false;
        slider.classList.remove('dragging');
      });
    });

    async function initialStatus() {
      const response = await fetch('/api/status', {cache: 'no-store'});
      if (!response.ok) throw new Error('status');
      render(await response.json());
    }

    initialStatus().catch(() => {
      byId('connection').lastElementChild.textContent = 'status niet bereikbaar';
    });

    const events = new EventSource('/api/events');
    events.onmessage = (event) => render(JSON.parse(event.data));
    events.onopen = () => byId('connection').classList.remove('connection-lost');
    events.onerror = () => {
      byId('connection').classList.add('connection-lost');
      byId('connection').lastElementChild.textContent = 'verbinding herstellen…';
    };
  </script>
</body>
</html>
""".encode("utf-8")


ASSETS = {
    "/assets/header-power-on.jpg": (
        "header-power-on.jpg",
        "image/jpeg",
    ),
    "/assets/header-power-off.jpg": (
        "header-power-off.jpg",
        "image/jpeg",
    ),
    "/assets/sam-processing-logo.png": (
        "sam-processing-logo.png",
        "image/png",
    ),
}


class StatusRequestHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def send_body(self, body, content_type, cache_control="no-store"):
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", cache_control)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def send_json(self, status_code, payload):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = self.path.split("?", 1)[0]

        if path == "/":
            self.send_body(STATUS_PAGE, "text/html; charset=utf-8")
            return

        if path == "/api/status":
            body = json.dumps(status_snapshot()).encode("utf-8")
            self.send_body(body, "application/json; charset=utf-8")
            return

        if path == "/api/events":
            self.send_events()
            return

        if path in ASSETS:
            filename, content_type = ASSETS[path]

            try:
                with open(os.path.join(WEB_ASSET_DIR, filename), "rb") as asset:
                    body = asset.read()
            except OSError:
                self.send_error(404)
                return

            self.send_body(body, content_type, "public, max-age=86400")
            return

        self.send_error(404)

    def send_events(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self.end_headers()
        last_revision = -1

        try:
            while True:
                revision, snapshot = wait_for_status(last_revision)

                if revision == last_revision:
                    self.wfile.write(b": keepalive\n\n")
                else:
                    body = json.dumps(snapshot).encode("utf-8")
                    self.wfile.write(b"data: " + body + b"\n\n")
                    last_revision = revision

                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, OSError):
            return

    def do_POST(self):
        path = self.path.split("?", 1)[0]

        if path != "/api/command":
            self.send_error(404)
            return

        content_type = self.headers.get("Content-Type", "")

        if not content_type.lower().startswith("application/json"):
            self.send_json(415, {"error": "Content-Type moet application/json zijn"})
            return

        try:
            content_length = int(self.headers.get("Content-Length", ""))
        except ValueError:
            self.send_json(411, {"error": "Content-Length ontbreekt"})
            return

        if content_length < 1 or content_length > 1024:
            self.send_json(413, {"error": "Ongeldige berichtgrootte"})
            return

        try:
            request = json.loads(
                self.rfile.read(content_length).decode("utf-8")
            )
        except (UnicodeDecodeError, json.JSONDecodeError):
            self.send_json(400, {"error": "Ongeldige JSON"})
            return

        if not isinstance(request, dict):
            self.send_json(400, {"error": "JSON-object verwacht"})
            return

        name = request.get("name")
        value = request.get("value")

        if not isinstance(name, str) or not isinstance(value, str):
            self.send_json(400, {"error": "name en value moeten tekst zijn"})
            return

        name = name.strip().upper()
        value = value.strip()

        if name not in WEB_COMMAND_NAMES:
            self.send_json(400, {"error": "Onbekend webcommando"})
            return

        if status_snapshot()["status"].get("serial") != "connected":
            self.send_json(503, {"error": "RS-232 is niet verbonden"})
            return

        if name != "POWER" and not is_ready():
            self.send_json(409, {"error": "Devialet is niet gereed"})
            return

        command_queue.put((name, value))
        schedule_web_status_query(name)
        self.send_json(
            202,
            {
                "accepted": True,
                "name": name,
                "value": value,
            },
        )

    def reject_write(self):
        self.send_error(405, "Methode niet toegestaan")

    do_PUT = reject_write
    do_PATCH = reject_write
    do_DELETE = reject_write
    do_OPTIONS = reject_write

    def log_message(self, format, *args):
        return


def serve_status():
    try:
        server = ThreadingHTTPServer(
            (HTTP_HOST, HTTP_PORT),
            StatusRequestHandler,
        )
    except OSError as error:
        print(f"Webserver kon niet starten: {error}", flush=True)
        return

    print(
        f"Statuswebsite luistert op {HTTP_HOST}:{HTTP_PORT}.",
        flush=True,
    )
    server.serve_forever()

def on_connect(client, userdata, flags, reason_code, properties):
    if reason_code != 0:
        print(
            f"MQTT-verbinding mislukt: {reason_code}",
            flush=True,
        )
        return

    print("MQTT verbonden.", flush=True)
    client.subscribe("devialet/command/+", qos=1)

    device = {
        "identifiers": ["devialet_rs232"],
        "name": "Devialet",
        "manufacturer": "Devialet",
        "model": "Expert via RS-232",
    }

    def publish_entity(
        component,
        object_id,
        config,
        requires_ready=True,
    ):
        config["device"] = device

        config["availability_topic"] = (
            "devialet/status/availability"
        )
        client.publish(
            f"homeassistant/{component}/{object_id}/config",
            json.dumps(config),
            qos=1,
            retain=True,
        )

    switches = [
        ("power", "Power", "mdi:power", False),
        ("mute", "Mute", "mdi:volume-mute", True),
        ("preout", "Pre-out", "mdi:audio-input-rca", True),
        ("subwoofer", "Subwoofer", "mdi:speaker", True),
        ("phase", "Phase", "mdi:sine-wave", True),
        (
            "subsonic_filter",
            "Subsonic filter",
            "mdi:filter",
            True,
        ),
        (
            "tone_control",
            "Tone Control",
            "mdi:tune-variant",
            True,
        ),
    ]

    for key, name, icon, requires_ready in switches:
        publish_entity(
            "switch",
            f"devialet_{key}",
            {
                "name": name,
                "unique_id": f"devialet_rs232_{key}",
                "command_topic": f"devialet/command/{key}",
                "state_topic": f"devialet/status/{key}",
                "payload_on": "1",
                "payload_off": "0",
                "icon": icon,
            },
            requires_ready,
        )

    numbers = [
        (
            "volume",
            "Volume",
            -80.0,
            10.0,
            0.5,
            "dB",
            "mdi:volume-high",
        ),
        (
            "balance",
            "Balance",
            -100,
            100,
            1,
            "%",
            "mdi:scale-balance",
        ),
        (
            "bass",
            "Bass",
            -18.0,
            18.0,
            0.5,
            "dB",
            "mdi:tune-vertical",
        ),
        (
            "treble",
            "Treble",
            -18.0,
            18.0,
            0.5,
            "dB",
            "mdi:tune-vertical",
        ),
        (
            "matching_level",
            "SAM extension",
            0,
            100,
            1,
            "%",
            "mdi:speaker-wireless",
        ),
    ]

    for key, name, minimum, maximum, step, unit, icon in numbers:
        publish_entity(
            "number",
            f"devialet_{key}",
            {
                "name": name,
                "unique_id": f"devialet_rs232_{key}",
                "command_topic": f"devialet/command/{key}",
                "state_topic": f"devialet/status/{key}",
                "min": minimum,
                "max": maximum,
                "step": step,
                "mode": "slider",
                "unit_of_measurement": unit,
                "icon": icon,
            },
        )

    publish_entity(
        "select",
        "devialet_source",
        {
            "name": "Source",
            "unique_id": "devialet_rs232_source",
            "command_topic": "devialet/command/source",
            "state_topic": "devialet/status/source",
            "options": [
                "AES/EBU",
                "Optical 1",
                "USB",
                "Denon AVR",
                "Phono",
                "UPnP",
                "Roon Ready",
                "AirPlay",
                "Spotify",
                "Air",
            ],
            "icon": "mdi:audio-input-stereo-minijack",
        },
    )

    publish("status/availability", "online")
    print("MQTT Discovery gepubliceerd.", flush=True)

def on_message(client, userdata, message):
    name = message.topic.rsplit("/", 1)[-1].upper()
    value = message.payload.decode("utf-8").strip()
    command_queue.put((name, value))

def send_command(connection, name, value):
    binary_commands = {
        "POWER",
        "MUTE",
        "PREOUT",
        "SUBWOOFER",
        "PHASE",
        "SUBSONIC_FILTER",
	"TONE_CONTROL",
    }

    valid_sources = {
        "AES/EBU",
        "Optical 1",
        "USB",
        "Denon AVR",
        "Phono",
        "UPnP",
        "Roon Ready",
        "AirPlay",
        "Spotify",
        "Air",
    }

    if name in binary_commands:
        if value not in {"0", "1"}:
            print(
                f"Commando geweigerd: {name}={value}",
                flush=True,
            )
            publish(
                "status/error",
                f"Ongeldige waarde: {name}={value}",
                False,
            )
            return

    elif name == "SOURCE":
        if value not in valid_sources:
            print(
                f"Commando geweigerd: SOURCE={value}",
                flush=True,
            )
            publish(
                "status/error",
                f"Onbekende bron: {value}",
                False,
            )
            return

    elif name == "VOLUME":
        try:
            numeric_value = float(value)
        except ValueError:
            numeric_value = None

        if (
            numeric_value is None
            or numeric_value < -80.0
            or numeric_value > 10.0
            or abs(numeric_value * 2 - round(numeric_value * 2))
            > 0.001
        ):
            print(
                f"Commando geweigerd: VOLUME={value}",
                flush=True,
            )
            publish(
                "status/error",
                f"Ongeldig volume: {value}",
                False,
            )
            return

    elif name == "BALANCE":
        try:
            balance_value = float(value)
        except ValueError:
            balance_value = None

        if (
            balance_value is None
            or balance_value < -100
            or balance_value > 100
            or not balance_value.is_integer()
        ):
            print(
                f"Commando geweigerd: BALANCE={value}",
                flush=True,
            )
            publish(
                "status/error",
                f"Ongeldige balance: {value}",
                False,
            )
            return

        value = str(int(balance_value))

    elif name in {"BASS", "TREBLE"}:
        try:
            tone_value = float(value)
        except ValueError:
            tone_value = None

        if (
            tone_value is None
            or tone_value < -18.0
            or tone_value > 18.0
            or abs(tone_value * 2 - round(tone_value * 2))
            > 0.001
        ):
            print(
                f"Commando geweigerd: {name}={value}",
                flush=True,
            )
            publish(
                "status/error",
                f"Ongeldige toonwaarde: {name}={value}",
                False,
            )
            return

    elif name == "MATCHING_LEVEL":
        try:
            matching_level = int(value)
        except ValueError:
            matching_level = None

        if (
            matching_level is None
            or matching_level < 0
            or matching_level > 100
        ):
            print(
                f"Commando geweigerd: MATCHING_LEVEL={value}",
                flush=True,
            )
            publish(
                "status/error",
                f"Ongeldig SAM-niveau: {value}",
                False,
            )
            return

    else:
        print(f"Commando geweigerd: onbekend {name}", flush=True)
        publish(
            "status/error",
            f"Onbekend commando: {name}",
            False,
        )
        return

    if name != "POWER" and not is_ready():
        print(
            f"Commando geblokkeerd: {name}; Devialet niet gereed",
            flush=True,
        )
        publish(
            "status/error",
            f"Devialet niet gereed voor {name}",
            False,
        )
        return

    command = f"[Devialet>{name}={value}]"
    connection.write(command.encode("ascii"))
    connection.flush()

    print(f"Commando verzonden: {name}={value}", flush=True)
    publish("status/last_command", f"{name}={value}", False)

def process_commands(connection):
    while True:
        try:
            name, value = command_queue.get_nowait()
        except queue.Empty:
            return

        send_command(connection, name, value)


def query_status(connection):
    for name in QUERY_NAMES:
        query = f"[Devialet>{name}=?]"
        connection.write(query.encode("ascii"))
        connection.flush()
        print(f"Status opgevraagd: {name}", flush=True)
        time.sleep(0.1)


def query_readiness(connection):
    names = ["POWER"]

    if not is_ready():
        names.extend(("START", "STOP"))

    for name in names:
        query = f"[Devialet>{name}=?]"
        connection.write(query.encode("ascii"))
        connection.flush()
        time.sleep(0.05)


def query_web_status(connection, names):
    for name in sorted(names):
        query = f"[Devialet>{name}=?]"
        connection.write(query.encode("ascii"))
        connection.flush()
        time.sleep(0.05)


def listen():
    global full_status_refresh_pending, previous_ready
    global web_status_query_due

    while True:
        try:
            store_status("POWER", None)
            store_status("START", None)
            store_status("STOP", None)
            store_status("SERIAL", "disconnected")
            previous_ready = None
            update_ready()

            print(
                f"Verbinden met {PORT} op {BAUDRATE} baud...",
                flush=True,
            )

            with serial.Serial(
                port=PORT,
                baudrate=BAUDRATE,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                timeout=0.2,
                xonxoff=False,
                rtscts=False,
                dsrdtr=False,
            ) as connection:
                print("Seriële verbinding geopend.", flush=True)
                store_status("SERIAL", "connected")
                publish("status/serial", "connected")
                query_status(connection)
                full_status_refresh_pending = False
                next_readiness_query = (
                    time.monotonic() + READY_QUERY_INTERVAL
                )

                receive_buffer = b""
    
                while True:
                    process_commands(connection)

                    if full_status_refresh_pending:
                        print(
                            "Devialet opnieuw gereed; volledige status synchroniseren.",
                            flush=True,
                        )
                        query_status(connection)
                        full_status_refresh_pending = False

                    now = time.monotonic()

                    if now >= next_readiness_query:
                        query_readiness(connection)
                        next_readiness_query = (
                            now + READY_QUERY_INTERVAL
                        )

                    names_to_query = None

                    with state_lock:
                        if (
                            web_status_query_due is not None
                            and now >= web_status_query_due
                        ):
                            names_to_query = set(web_status_query_names)
                            web_status_query_names.clear()
                            web_status_query_due = None

                    if names_to_query:
                        query_web_status(connection, names_to_query)

                    data = connection.read(1)
    
                    if data:
                        receive_buffer += data
    
                        while b"]" in receive_buffer:
                            raw_message, receive_buffer = receive_buffer.split(b"]", 1)
                            raw_message += b"]"
    
                            message = raw_message.decode(
                                "ascii",
                                errors="replace",
                            ).strip()
    
                            if message:
                                print(f"Ontvangen: {message}", flush=True)
                                process_message(message)
        except serial.SerialException as error:
            print(f"Seriële fout: {error}", flush=True)
            store_status("SERIAL", "disconnected")
            publish("status/serial", "disconnected")
            publish("status/ready", "false")
            time.sleep(RECONNECT_DELAY)


def main():
    global mqtt_client

    mqtt_client = mqtt.Client(
        mqtt.CallbackAPIVersion.VERSION2,
        client_id="devialet-rs232",
    )
    mqtt_client.username_pw_set(MQTT_USERNAME, MQTT_PASSWORD)
    mqtt_client.will_set(
        "devialet/status/availability",
        "offline",
        qos=1,
        retain=True,
    )
    mqtt_client.on_connect = on_connect
    mqtt_client.on_message = on_message
    mqtt_client.connect_async(MQTT_HOST, MQTT_PORT, 60)
    mqtt_client.loop_start()

    threading.Thread(
        target=serve_status,
        name="devialet-status-web",
        daemon=True,
    ).start()
    listen()


if __name__ == "__main__":
    main()
