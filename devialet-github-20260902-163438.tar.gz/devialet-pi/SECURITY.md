# Security

Never commit `/etc/devialet/devialet.env`, `.env`, `*.env`, private backup archives, MQTT passwords, access tokens, private keys or certificates.

The web interface and API do not provide authentication. Keep port 8080 on a trusted local network or place it behind a VPN or reverse proxy with HTTPS and authentication. Do not expose the port directly through an internet router.

Before publishing changes, run:

```sh
./scripts/check-secrets.sh
```

This basic safety check is not a substitute for reviewing the staged files and commit diff.

If a secret is accidentally committed, removing it from the latest commit is not sufficient. Rotate the exposed secret immediately and, when necessary, purge it from the complete Git history.
