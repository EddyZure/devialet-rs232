#!/bin/sh
set -eu

if [ "$#" -ne 1 ] || [ ! -f "$1" ]; then
  echo "Gebruik: sudo ./scripts/restore.sh /pad/naar/devialet-private-backup-...tar.gz" >&2
  exit 1
fi
if [ "$(id -u)" -ne 0 ]; then
  echo "Voer dit script uit met sudo." >&2
  exit 1
fi

ARCHIVE=$1
TMP_DIR=$(mktemp -d)
trap 'rm -rf "$TMP_DIR"' EXIT HUP INT TERM
tar -xzf "$ARCHIVE" -C "$TMP_DIR"

if [ ! -f "$TMP_DIR/private/devialet.env" ]; then
  echo "Dit archief bevat geen private/devialet.env." >&2
  exit 1
fi

install -d -m 700 /etc/devialet
install -m 600 "$TMP_DIR/private/devialet.env" /etc/devialet/devialet.env

if [ -d "$TMP_DIR/private/src" ]; then
  install -d -o devialet -g devialet /opt/devialet/src
  cp -R "$TMP_DIR/private/src/." /opt/devialet/src/
  chown -R devialet:devialet /opt/devialet/src
fi

systemctl restart devialet-bridge.service
systemctl --no-pager --full status devialet-bridge.service || true
