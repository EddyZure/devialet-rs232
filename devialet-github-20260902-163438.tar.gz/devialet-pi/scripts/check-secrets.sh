#!/bin/sh
set -eu

PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$PROJECT_DIR"

FAILED=0
for path in .env devialet.env; do
  if [ -e "$path" ]; then
    echo "Niet veilig voor GitHub: $path bestaat." >&2
    FAILED=1
  fi
done

if find . -type f \( -name '*.tar.gz' -o -name '*.pem' -o -name '*.key' \) -not -path './.git/*' | grep -q .; then
  echo "Waarschuwing: mogelijk gevoelig archief of sleutelbestand gevonden." >&2
  FAILED=1
fi

if grep -R -E -n --exclude='.env.example' --exclude='check-secrets.sh' --exclude-dir='.git' --exclude='README.md' '(MQTT_PASSWORD|PASSWORD|TOKEN|SECRET)=[^[:space:]]+' .; then
  echo "Mogelijk ingevuld geheim gevonden." >&2
  FAILED=1
fi

if [ "$FAILED" -ne 0 ]; then
  exit 1
fi
echo "Geen bekende secret-bestanden of ingevulde credentials gevonden."
